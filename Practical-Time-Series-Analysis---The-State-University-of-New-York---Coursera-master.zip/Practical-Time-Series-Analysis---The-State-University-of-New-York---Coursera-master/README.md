# Practical-Time-Series-Analysis---The-State-University-of-New-York---Coursera
Course materials for the Coursera MOOC: Practical Time Series Analysis from The State University of New York
