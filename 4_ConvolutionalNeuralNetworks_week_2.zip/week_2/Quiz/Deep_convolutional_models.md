## Week 2 quiz - Deep convolutional models

1. Which of the following do you typically see in a ConvNet? (Check all that apply.)

	[X] Multiple CONV layers followed by a POOL layer

	[] Multiple POOL layers followed by a CONV layer

	[X] FC layers in the last few layers

	[] FC layers in the first few layers

2. In order to be able to build very deep networks, we usually only use pooling layers to downsize the height/width of the activation volumes while convolutions are used with “valid” padding. Otherwise, we would downsize the input of the model too quickly.

	[] True

	[X] False

3. Training a deeper network (for example, adding additional layers to the network) allows the network to fit more complex functions and thus almost always results in lower training error. For this question, assume we’re referring to “plain” networks.

	[] True

	[X] False

4. The following equation captures the computation in a ResNet block. What goes into the two blanks above?
```
a[l+2]=g(W[l+2]g(W[l+1]a[l]+b[l+1])+bl+2+_______ )+_______
```

	[X] a[l] and 0, respectively

	[] 0 and z[l+1], respectively

	[] z[l] and a[l], respectively

	[] 0 and a[l], respectively

5. Which ones of the following statements on Residual Networks are true? (Check all that apply.)

	[X] Using a skip-connection helps the gradient to backpropagate and thus helps you to train deeper networks

	[] A ResNet with L layers would have on the order of L2 skip connections in total.

	[] The skip-connections compute a complex non-linear function of the input to pass to a deeper layer in the network.

	[X] The skip-connection makes it easy for the network to learn an identity mapping between the input and the output within the ResNet block.

6. Suppose you have an input volume of dimension nH x nW x nC. Which of the following statements you agree with? (Assume that “1x1 convolutional layer” below always uses a stride of 1 and no padding.)

	[X] You can use a 1x1 convolutional layer to reduce nC but not nH, nW.

	[] You can use a 1x1 convolutional layer to reduce nH, nW, and nC.

	[X] You can use a pooling layer to reduce nH, nW, but not nC.

	[] You can use a pooling layer to reduce nH, nW, and nC.

7. Which ones of the following statements on Inception Networks are true? (Check all that apply.)

	[X] A single inception block allows the network to use a combination of 1x1, 3x3, 5x5 convolutions and pooling.

	[] Making an inception network deeper (by stacking more inception blocks together) should not hurt training set performance.

	[X] Inception blocks usually use 1x1 convolutions to reduce the input data volume’s size before applying 3x3 and 5x5 convolutions.

	[] Inception networks incorporates a variety of network architectures (similar to dropout, which randomly chooses a network architecture on each step) and thus has a similar regularizing effect as dropout.

8. Which of the following are common reasons for using open-source implementations of ConvNets (both the model and/or weights)? Check all that apply.

	[] A model trained for one computer vision task can usually be used to perform data augmentation even for a different computer vision task.

	[X] It is a convenient way to get working an implementation of a complex ConvNet architecture.

	[] The same techniques for winning computer vision competitions, such as using multiple crops at test time, are widely used in practical deployments (or production system deployments) of ConvNets.

	[X] Parameters trained for one computer vision task are often useful as pretraining for other computer vision tasks.

9. In Depthwise Separable Convolution you:

	[] You convolve the input image with a filter of nJ x nF x nC where nC acts as the depth of the filter (nC is the number of color channels of the input image).

	[] Perform one step of convolution.

	[] The final output is of the dimension nOut x nOut x nC (where nC is the number of color channels of the input image).

	[] You convolve the input image with nC number of nF x nF filters (nC is the number of color channels of the input image).

	[X] For the “Depthwise” computations each filter convolves with only one corresponding color channel of the input image.

	[] For the “Depthwise” computations each filter convolves with all of the color channels of the input image.

	[X] Perform two steps of convolution.

	[] The final output is of the dimension nOut x nOut x nC (where nC is the number of filters used in the previous convolution step).

10. Fill in the missing dimensions shown in the image below (marked W, Y, Z).

	[] W = 30, Y = 30, Z = 5

	[] W = 30, Y = 20, Z =20

	[X] W = 5, Y = 30, Z = 20

	[] W = 5, Y = 20, Z = 5
