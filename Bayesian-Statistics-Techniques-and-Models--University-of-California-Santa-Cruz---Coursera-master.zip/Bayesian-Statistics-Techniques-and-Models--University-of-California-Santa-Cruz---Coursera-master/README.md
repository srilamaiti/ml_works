# Bayesian-Statistics-Techniques-and-Models--University-of-California-Santa-Cruz---Coursera
Course materials for the Coursera MOOC: Bayesian Statistics Techniques and Models from University of California Santa Cruz
